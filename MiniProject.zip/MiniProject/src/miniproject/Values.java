/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miniproject;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 *
 * @author HritikShrestha
 * 
 * This class is created primely to create a file and store the values and formulae in a CSV format...
 */
public class Values {
    public static void main(String[] args){
        try {
            try (FileWriter csvWriter = new FileWriter("Values and Formulae.csv")) {
                csvWriter.append("Fuelcost=1.03");
                csvWriter.append(",");
                csvWriter.append("Fuelcost=1.05");
                csvWriter.append(",");
                csvWriter.append("totalcost=Fuelcost*MPG*Tripdistance");
                csvWriter.flush();
            }

        } catch (IOException e) {
            System.out.println("There was an error processing with the file!!!");
        }
    
    
    
    }
    
}
