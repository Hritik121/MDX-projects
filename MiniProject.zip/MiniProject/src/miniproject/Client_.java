package miniproject;


import java.io.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Client_ extends Application{
    //Creating fixed Text Fields and Labels and Buttons which are to be used in the program.
    //They will reamin the same so they are declared as final.
    private final TextField TripDistance = new TextField();
    private final TextField MilesPerGallon = new TextField();
    private final RadioButton octane = new RadioButton("Octane(£1.03)");
    private final RadioButton diesel = new RadioButton("Diesel(£1.05)");
    private final TextField CostofFuel = new TextField("");
    public static final String Delimiter = ",";
    public static  double Tripdistance=0;
    public static  double MPG=0;
    public static  double Fuelcost=0;
    public static double totalcost=0;
//Delimeter is declared as Static so that it can be used in other classes as well
    
    
    @Override
    public void start(Stage primaryStage) {
        
      //GridPane is used as it places the nodes under two axes.
      GridPane pane = new GridPane(); 
      pane.setAlignment(Pos.CENTER); //It sets the alignment of the nodes.
      pane.setPadding(new Insets(10, 10, 10, 10));//Insets are used for padding the nodes in a scene.
      pane.setHgap(5.5);//Sets the Horizontal Gap between the the nodes.
      pane.setVgap(5.5);//Sets the Vertical Gap between the nodes.
      CostofFuel.setEditable(false);//It prevents the TextField from being edited by the user.

      // Place nodes in the pane according to the co-ordinates.
      
      pane.add(new Label("Trip Distance"), 0, 0); 
      pane.add(TripDistance, 1, 0);
      pane.add(new Label("Miles Per Gallon"), 0, 1);
      pane.add(MilesPerGallon, 1, 1);
      pane.add(new Label("Fuel used:"), 0, 2);
      pane.add(new Label("Total Fuel Cost:"), 0, 5);
      pane.add(CostofFuel,1,5);
      pane.add(new Label(), 1, 0); 
      pane.add(octane, 0, 3);
      pane.add(diesel, 1, 3);
      
     //Toggle Group so that only one of the radio button is selected...
      ToggleGroup group = new ToggleGroup();
      octane.setToggleGroup(group);
      octane.setSelected(true);
      diesel.setToggleGroup(group);
     //A button is created tp carry out the action to find the total fuel cost.
      Button Calculate = new Button("Calculate");
      pane.add(Calculate,1,4);
      //The set on action is used to carry out Button action so that it gives a value when it is pressed...
      Calculate.setOnAction(e -> calculateTotalFuelCost());
      // A scene is defined to place all our nodes and to create a GUI for the user, with parameters 
       //such as the pane used and the size of the scene(length and width)...
       Scene scene=new Scene(pane,300,300);
       primaryStage.setTitle("Calculate Total Fuel Cost of a Trip");//Sets the title of the Scene...
       primaryStage.setScene(scene);
       primaryStage.show();//This is carried out to call the scene and be displayed on the users Screen...
       
    }
    
    //A method is declared to carry out the function of calculating the total fuel cost...
    private void calculateTotalFuelCost(){
        
        
        
        try {
            Tripdistance=Double.parseDouble(TripDistance.getText());
            MPG=Double.parseDouble(MilesPerGallon.getText());
            
        } catch (Exception e) {
            System.out.println("The text Fields are empty or the data entered is incorrect.");
            CostofFuel.setText("0");
        }
        
        if (octane.isSelected()) {
            Fuelcost=1.03;
            
        }else{
            Fuelcost=1.05;
        }
        
        totalcost=Fuelcost*MPG*Tripdistance;
        CostofFuel.setText(String.format("%.2f",totalcost ));
        
        
        
        
       //////////////////////////////////////////////
//        File file = new File("Values and Formulae.csv");
        try {
            FileWriter fr = new FileWriter("Values and Formulae.csv",true);
            
            fr.append(String.valueOf(MPG));
            fr.append(Delimiter);
            fr.append(String.valueOf(Tripdistance));
            fr.append(Delimiter);
            fr.append(String.valueOf(Fuelcost));
            fr.append(Delimiter);
            fr.append(String.valueOf(totalcost));
            fr.append("\n");
            fr.flush();
            fr.close();
            
         
         } catch(IOException e) {
             System.out.println("File not Found");
         }
        
        
        
        
        
    }
    //This is our main method...
    public static void main(String[] args) {
        
        System.out.println("Launch");
        
        
        
//        try {
//            FileReader fr = new FileReader(file);
//            BufferedReader br = new BufferedReader(fr);
//            String line="";
//            String[] tempArr;
//            
//            while((line = br.readLine()) != null) {
//                tempArr = line.split(Delimiter);
//                
//                System.out.println(tempArr[2]);
//                System.out.println();
//            }
//         
//            br.close();
//         
//         } catch(IOException e) {
//             System.out.println("File not Found");
//         }


        
        //It launches our JAVAFX GUI programme...
        launch(args);
        
    }
    
}
  